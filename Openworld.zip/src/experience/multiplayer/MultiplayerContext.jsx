import { createContext } from 'react';

export const MultiplayerContext = createContext(null);
